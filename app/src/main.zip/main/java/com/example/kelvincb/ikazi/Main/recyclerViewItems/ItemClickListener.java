package com.example.kelvincb.ikazi.Main.recyclerViewItems;

import android.view.View;

public interface ItemClickListener {

    void onItemClick(View v,int pos);
}
