package com.example.kelvincb.ikazi.Main.mainFragments.userHistory.processedRequestPackage;

public class processedGetterSetters {
    String user_name,user_phone_number,mdate,mtime,jobDescription,landmark,workerId,worker_name,occupation,imageUrl,worker_phone_number;

    public String getUser_name() {
        return user_name;
    }

    public String getUser_phone_number() {
        return user_phone_number;
    }

    public String getMdate() {
        return mdate;
    }

    public String getMtime() {
        return mtime;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public String getLandmark() {
        return landmark;
    }

    public String getWorkerId() {
        return workerId;
    }

    public String getWorker_name() {
        return worker_name;
    }

    public String getOccupation() {
        return occupation;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getWorker_phone_number() {
        return worker_phone_number;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public void setUser_phone_number(String user_phone_number) {
        this.user_phone_number = user_phone_number;
    }

    public void setMdate(String mdate) {
        this.mdate = mdate;
    }

    public void setMtime(String mtime) {
        this.mtime = mtime;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public void setWorkerId(String workerId) {
        this.workerId = workerId;
    }

    public void setWorker_name(String worker_name) {
        this.worker_name = worker_name;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setWorker_phone_number(String worker_phone_number) {
        this.worker_phone_number = worker_phone_number;
    }
}
