package com.example.kelvincb.ikazi.Main.mainFragments.userHistory.processingRequest;

public class processingGetterSetters {

    String workerId,status,name,occupation,imageUrl;

    public String getWorkerId() {
        return workerId;
    }

    public String getStatus() {
        return status;
    }

    public String getName() {
        return name;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setWorkerId(String workerId) {
        this.workerId = workerId;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
