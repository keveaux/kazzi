package com.example.kelvincb.ikazi.UserLoginAndRegister;

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.kelvincb.ikazi.UserLoginAndRegister.userLogin.firebaseStuff.beforeLogin;
import com.example.kelvincb.ikazi.R;
import com.example.kelvincb.ikazi.splashScreen.SplashScreenActivity;

public class LoginRegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_register);


        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.userFragmentContainer, new beforeLogin());
        fragmentTransaction.commit();

//       switch (getIntent().getStringExtra("EXTRA")){
//           case "openLogin":
//               String pno=getIntent().getStringExtra("message");
//               Bundle bundle = new Bundle();
//               bundle.putString("EXTRA","second");
//               bundle.putString("pno",pno);
//               beforeLogin ob = new beforeLogin();
//               ob.setArguments(bundle);
//               getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, ob)
//                       .addToBackStack(null).commit();
//               break;
//
//               default:
//       }

    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent(LoginRegisterActivity.this, SplashScreenActivity.class);
        startActivity(intent);
        super.onBackPressed();
    }
}
