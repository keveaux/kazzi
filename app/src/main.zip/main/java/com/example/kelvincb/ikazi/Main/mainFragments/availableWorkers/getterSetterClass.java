package com.example.kelvincb.ikazi.Main.mainFragments.availableWorkers;

public class getterSetterClass {
    String id,name,rating,numberOfRates,imageUrl,occupation,longitude,latitude,skillSet,phoneNumber;
    float distance;

    public String getName() {
        return name;
    }

    public String getRating() {
        return rating;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String getNumberOfRates() {
        return numberOfRates;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public void setNumberOfRates(String numberOfRates) {
        this.numberOfRates = numberOfRates;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getOccupation() {
        return occupation;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getSkillSet() {
        return skillSet;
    }

    public void setSkillSet(String skillSet) {
        this.skillSet = skillSet;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }
}
