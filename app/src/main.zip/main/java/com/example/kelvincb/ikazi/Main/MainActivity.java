package com.example.kelvincb.ikazi.Main;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.MenuItem;

import com.example.kelvincb.ikazi.Main.mainFragments.availableWorkers.availableWorkersFragment;
import com.example.kelvincb.ikazi.Main.mainFragments.mainFragment;
import com.example.kelvincb.ikazi.Main.mainFragments.userHistory.myHistoryFragment;
import com.example.kelvincb.ikazi.Main.mainFragments.userProfile;
import com.example.kelvincb.ikazi.R;


public class MainActivity extends AppCompatActivity {

    Fragment fragment;
    BottomNavigationView navigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        navigation =  findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        navigation.getMenu().getItem(0).setChecked(true);


        switch (getIntent().getStringExtra("EXTRA")) {

            case "openAvailableWorkers":
            String latitude = getIntent().getStringExtra("lat");
            String longitude = getIntent().getStringExtra("lon");
            String occupation=getIntent().getStringExtra("occupation");
            Bundle bundle = new Bundle();
            bundle.putString("EXTRA","second");
            bundle.putString("lat", latitude);
            bundle.putString("lon", longitude);
            bundle.putString("occupation",occupation);
            availableWorkersFragment ob = new availableWorkersFragment();
            ob.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_container, ob)
                    .addToBackStack(null).commit();
                break;
                default:
            fragment = new mainFragment();
            loadFragment(fragment);
        }
    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()) {
                case R.id.navigation_home:
                    fragment=new mainFragment();
                    loadFragment(fragment);
                    return true;

                case R.id.navigation_history:
                    fragment=new myHistoryFragment();
                    loadFragment(fragment);
                    return true;

                case R.id.navigation_profile:
                    fragment = new userProfile();
                    loadFragment(fragment);
                    return true;
            }
            return false;
        }
    };

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }



    @Override
    public void onBackPressed() {
        if (navigation.getSelectedItemId() == R.id.navigation_home) {
            super.onBackPressed();
        } else {
            navigation.setSelectedItemId(R.id.navigation_home);
        }
    }

}
